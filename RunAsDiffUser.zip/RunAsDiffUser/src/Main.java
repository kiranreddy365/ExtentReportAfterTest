import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Main {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		//System.setProperty("webdriver.chrome.driver", "D:\\BhaveshN\\Automation\\SetupAndReferences\\chromedriver_win32\\chromedriver.exe"); 
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "\\browser\\chromedriver.exe"); 
		WebDriver driver = new ChromeDriver();
		driver.get("https://sohodragon.sharepoint.com/Pages/Home.aspx");
		Thread.sleep(5000);
		
		//driver.quit();
	}

}
